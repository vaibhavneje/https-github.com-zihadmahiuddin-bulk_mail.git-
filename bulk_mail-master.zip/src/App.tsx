import React from "react";
import Home from "./screens/Home";

const App: React.FC = () => {
  return <Home />;
};

export default App;
